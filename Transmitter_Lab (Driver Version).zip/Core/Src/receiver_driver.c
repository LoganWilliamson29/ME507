/*
 * receiver_driver.c
 *
 *  Created on: Jul 26, 2022
 *      Author: Cole Marin, Caleb Savard, Logan Williamson
 */

#include "receiver_driver.h"

void Get_Widths(RC_t* receiver)
/*Function courtesy of:
 * Controllers Tech (2020) Measuring Pulse Width [Source Code]. https://controllerstech.com/input-capture-in-stm32/
 */
{
	if (receiver->THR_Edge == 0)
	{
		receiver->THR_Val1 = HAL_TIM_ReadCapturedValue(receiver->htim,receiver->THR_CH);
		receiver->THR_Edge = 1;
	}
	else
	{
		receiver->THR_Val2 = HAL_TIM_ReadCapturedValue(receiver->htim,receiver->THR_CH);
		if (receiver->THR_Val2 > receiver->THR_Val1)
		{
			receiver->THR_Width = (receiver->THR_Val2 - receiver->THR_Val1) - 13000;
		}
		else if (receiver->THR_Val1 > receiver->THR_Val2)
		{
			receiver->THR_Width = ((0xffff - receiver->THR_Val1) + receiver->THR_Val2) - 13000;
		}
		receiver->THR_Edge = 0;
	}
	if (receiver->STR_Edge == 0)
	{
		receiver->STR_Val1 = HAL_TIM_ReadCapturedValue(receiver->htim,receiver->STR_CH);
		receiver->STR_Edge = 1;
	}
	else
	{
		receiver->STR_Val2 = HAL_TIM_ReadCapturedValue(receiver->htim,receiver->STR_CH);
		if (receiver->STR_Val2 > receiver->STR_Val1)
		{
			receiver->STR_Width = (receiver->STR_Val2 - receiver->STR_Val1) - 13000;
		}
		else if (receiver->STR_Val1 > receiver->STR_Val2)
		{
			receiver->STR_Width = ((0xffff - receiver->STR_Val1) + receiver->STR_Val2) - 13000;
		}
		receiver->STR_Edge = 0;
	}
}
