/*
 * receiver_driver.h
 *
 *  Created on: Jul 26, 2022
 *      Author: Cole Marin, Caleb Savard, Logan Williamson
 */

#ifndef SRC_RECEIVER_DRIVER_H_
#define SRC_RECEIVER_DRIVER_H_

#include "stm32f4xx_hal.h"
#include "stm32f4xx_hal_tim.h"

struct RC
{
	TIM_HandleTypeDef* 		htim;				// HAL Handle struct for PWM Timer
	uint32_t 				STR_CH;				// Input timer channel 1 pin callout
	uint32_t 				THR_CH;				// Input timer channel 2 pin callout
	uint8_t 				THR_Edge; 			// Throttle channel rising versus falling edge tracker
	uint8_t					STR_Edge;			// Steering channel rising versus falling edge tracker
	uint16_t 				STR_Val1;			// Latched tim_ch_a rising edge timer value upon interrupt callback
	uint16_t 				STR_Val2;			// Latched tim_ch_a falling edge time value upon interrupt callback
	uint16_t				STR_Width;			// Pulse width of steering signal, channel 1
	uint16_t 				THR_Val1;			// Latched tim_ch_a rising edge timer value upon interrupt callback
	uint16_t 				THR_Val2;			// Latched tim_ch_a falling edge time value upon interrupt callback
	uint16_t				THR_Width;			// Pulse width of throttle signal, channel 2
} typedef RC_t;

void Get_Widths(RC_t* receiver);

#endif /* SRC_RECEIVER_DRIVER_H_ */
